
function submitForm(e){
  e.preventDefault();
  const status = document.getElementById('status');
  const name = document.getElementById('name').value.trim();
  status.textContent = 'Thanks ' + (name || '') + '! Your message was captured (demo).';
  document.getElementById('contactForm').reset();
  // In a real site you'd send the data to a server here.
}
